# Trust-Issues
A mock website for IGME 430 that is part social media and part mass trust game.
