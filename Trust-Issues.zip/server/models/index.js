// module.exports.[modelName] = require('./[modelName].js');
module.exports.Account = require('./Account.js');
module.exports.TrustUsGame = require('./TrustUsGame.js');
