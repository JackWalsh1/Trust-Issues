// module.exports.[modelName] = require('./[modelName].js');
module.exports.Account = require('./Account.js');
module.exports.AccountPage = require('./AccountPage.js');
module.exports.GamePortal = require('./GamePortal.js');
module.exports.TrustUs = require('./TrustUs.js');
